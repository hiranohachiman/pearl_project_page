from smart_open import open
import zipfile
import os

def download_dataset(s3_url, extract_to_dir):
    if not os.path.exists(extract_to_dir):
        os.makedirs(extract_to_dir)
    with open(s3_url, 'rb') as s3_file:
        with zipfile.ZipFile(s3_file, 'r') as zip_ref:
            zip_ref.extractall(extract_to_dir)
            
def download_ckpt(s3_url, ckpt_file_path):
    if not os.path.exists(os.path.dirname(ckpt_file_path)):
        os.makedirs(os.path.dirname(ckpt_file_path))
    with open(s3_url, 'rb') as s3_file:
        with open(ckpt_file_path, 'wb') as local_file:
            local_file.write(s3_file.read())
    
if __name__ == '__main__':
    dataset_url = ''
    dataset_dir = 'data_en/'
    ckpt_url = ''
    ckpt_path = 'experiments/reproduce.ckpt'
    print('Downloading dataset...')
    download_dataset(dataset_url, dataset_dir)
    print('Downloading checkpoint...')
    download_ckpt(ckpt_url, ckpt_path)
