# Pearl

This repository contains the code for Pearl.

## Installation


Create a Python 3.10 virtual environment using pyenv and install dependencies:

```bash
pyenv virtualenv 3.10.0 pearl
pyenv local pearl # cuda=11.8
```

## Training

Start training by running:

```bash
sh train.sh
```

## Evaluation

Before evaluating, ensure that PAC-S checkpoints are downloaded and placed as specified in the authors' instructions on the [PACScore GitHub](https://github.com/aimagelab/pacscore). Then run:

```bash
sh validate.sh
```
