ckpt=`find . -name "*.ckpt" | xargs ls -lt | awk '{ print $NF }' | grep -v '^$' | head -n 2 | tail -n 1`
echo $ckpt
python validate/validate_cvpr.py --model=$ckpt --foil --pearl --coef --flickr